<?php 
session_start();
#if(!isset($_SESSION['user_guess'])){

#}else {
#    header('Location: index.php');
#}
#get user submited data
$_SESSION['actual_number'] = mt_rand(1,10);
$user_guess = filter_input(INPUT_GET, 'user_guess', FILTER_VALIDATE_INT);
if($_SESSION['user_guess'] == NULL ){
$_SESSION['user_guess']= $user_guess;
    header('Location: index.php');
}
header('Location: index.php');

?>